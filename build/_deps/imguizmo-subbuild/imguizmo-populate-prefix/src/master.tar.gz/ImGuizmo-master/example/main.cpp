// https://github.com/CedricGuillemet/ImGuizmo
// v1.92.5 WIP
//
// The MIT License(MIT)
//
// Copyright(c) 2016-2026 Cedric Guillemet and contributors
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files(the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions :
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#define IMAPP_IMPL
#include "ImApp.h"

#ifdef None
#undef None
#endif

#include "ImGuizmo.h"
#include "ImSequencer.h"
#include "ImZoomSlider.h"
#include "ImCurveEdit.h"
#include "ImVectorEditor.h"
#include "GraphEditor.h"
#include "ImLightRig.h"
#include <cmath>
#include <cstdio>
#include <vector>
#include <algorithm>

bool useWindow = true;
int gizmoCount = 1;
bool gizmoEnabled[4] = { true, true, true, true };

// Optional second viewport with its own camera
bool useSecondView = false;
float cameraView2[16] =
{ 1.f, 0.f, 0.f, 0.f,
  0.f, 1.f, 0.f, 0.f,
  0.f, 0.f, 1.f, 0.f,
  0.f, 0.f, 0.f, 1.f };
float camDistance2 = 8.f;
float camYAngle2 = 165.f / 180.f * 3.14159f;
float camXAngle2 = 32.f / 180.f * 3.14159f;
float camDistance = 8.f;
float camYAngle = 165.f / 180.f * 3.14159f;
float camXAngle = 32.f / 180.f * 3.14159f;
static ImGuizmo::OPERATION mCurrentGizmoOperation(ImGuizmo::TRANSLATE);
static ImGuizmo::MODE mCurrentGizmoMode(ImGuizmo::WORLD);
static bool useSnap(false);
static float snap[3] = { 1.f, 1.f, 1.f };
static float bounds[] = { -0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f };
static float boundsSnap[] = { 0.1f, 0.1f, 0.1f };
static bool boundSizingSnap = false;

float objectMatrix[4][16] = {
  { 1.f, 0.f, 0.f, 0.f,
    0.f, 1.f, 0.f, 0.f,
    0.f, 0.f, 1.f, 0.f,
    0.f, 0.f, 0.f, 1.f },

  { 1.f, 0.f, 0.f, 0.f,
  0.f, 1.f, 0.f, 0.f,
  0.f, 0.f, 1.f, 0.f,
  2.f, 0.f, 0.f, 1.f },

  { 1.f, 0.f, 0.f, 0.f,
  0.f, 1.f, 0.f, 0.f,
  0.f, 0.f, 1.f, 0.f,
  2.f, 0.f, 2.f, 1.f },

  { 1.f, 0.f, 0.f, 0.f,
  0.f, 1.f, 0.f, 0.f,
  0.f, 0.f, 1.f, 0.f,
  0.f, 0.f, 2.f, 1.f }
};

static const float identityMatrix[16] =
{ 1.f, 0.f, 0.f, 0.f,
    0.f, 1.f, 0.f, 0.f,
    0.f, 0.f, 1.f, 0.f,
    0.f, 0.f, 0.f, 1.f };

void Frustum(float left, float right, float bottom, float top, float znear, float zfar, float* m16, bool rightHanded)
{
   float temp = 2.0f * znear;
   float temp2 = right - left;
   float temp3 = top - bottom;
   float temp4 = zfar - znear;
   float sign = rightHanded ? -1.0f : 1.0f;
   m16[0] = temp / temp2;
   m16[1] = 0.0f;
   m16[2] = 0.0f;
   m16[3] = 0.0f;
   m16[4] = 0.0f;
   m16[5] = temp / temp3;
   m16[6] = 0.0f;
   m16[7] = 0.0f;
   m16[8] = (right + left) / temp2;
   m16[9] = (top + bottom) / temp3;
   m16[10] = sign * (zfar + znear) / temp4;
   m16[11] = sign;
   m16[12] = 0.0f;
   m16[13] = 0.0f;
   m16[14] = -(temp * zfar) / temp4;
   m16[15] = 0.0f;
}

void Perspective(float fovyInDegrees, float aspectRatio, float znear, float zfar, float* m16, bool rightHanded = true, bool infiniteFarPlane = false)
{
   float ymax = znear * tanf(fovyInDegrees * 3.141592f / 180.0f);
   float xmax = ymax * aspectRatio;
   if (infiniteFarPlane)
   {
      float sign = rightHanded ? -1.0f : 1.0f;
      float temp = 2.0f * znear;
      float temp2 = 2.0f * xmax;
      float temp3 = 2.0f * ymax;
      m16[0] = temp / temp2;
      m16[1] = 0.0f;
      m16[2] = 0.0f;
      m16[3] = 0.0f;
      m16[4] = 0.0f;
      m16[5] = temp / temp3;
      m16[6] = 0.0f;
      m16[7] = 0.0f;
      m16[8] = 0.0f;
      m16[9] = 0.0f;
      m16[10] = sign;
      m16[11] = sign;
      m16[12] = 0.0f;
      m16[13] = 0.0f;
      // Keep the Z translation term negative for both handedness modes.
      // Using +2n in LH flips clipping orientation and appears like inverted winding.
      m16[14] = -temp;
      m16[15] = 0.0f;
   }
   else
   {
      Frustum(-xmax, xmax, -ymax, ymax, znear, zfar, m16, rightHanded);
   }
}

void Cross(const float* a, const float* b, float* r)
{
   r[0] = a[1] * b[2] - a[2] * b[1];
   r[1] = a[2] * b[0] - a[0] * b[2];
   r[2] = a[0] * b[1] - a[1] * b[0];
}

float Dot(const float* a, const float* b)
{
   return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

void Normalize(const float* a, float* r)
{
   float il = 1.f / (sqrtf(Dot(a, a)) + FLT_EPSILON);
   r[0] = a[0] * il;
   r[1] = a[1] * il;
   r[2] = a[2] * il;
}

void LookAt(const float* eye, const float* at, const float* up, float* m16, bool rightHanded = true)
{
   float X[3], Y[3], Z[3], tmp[3];

   if (rightHanded)
   {
      tmp[0] = eye[0] - at[0];
      tmp[1] = eye[1] - at[1];
      tmp[2] = eye[2] - at[2];
   }
   else
   {
      tmp[0] = at[0] - eye[0];
      tmp[1] = at[1] - eye[1];
      tmp[2] = at[2] - eye[2];
   }
   Normalize(tmp, Z);
   Normalize(up, Y);

   Cross(Y, Z, tmp);
   Normalize(tmp, X);

   Cross(Z, X, tmp);
   Normalize(tmp, Y);

   m16[0] = X[0];
   m16[1] = Y[0];
   m16[2] = Z[0];
   m16[3] = 0.0f;
   m16[4] = X[1];
   m16[5] = Y[1];
   m16[6] = Z[1];
   m16[7] = 0.0f;
   m16[8] = X[2];
   m16[9] = Y[2];
   m16[10] = Z[2];
   m16[11] = 0.0f;
   m16[12] = -Dot(X, eye);
   m16[13] = -Dot(Y, eye);
   m16[14] = -Dot(Z, eye);
   m16[15] = 1.0f;
}

void OrthoGraphic(const float l, float r, float b, const float t, float zn, const float zf, float* m16)
{
   m16[0] = 2 / (r - l);
   m16[1] = 0.0f;
   m16[2] = 0.0f;
   m16[3] = 0.0f;
   m16[4] = 0.0f;
   m16[5] = 2 / (t - b);
   m16[6] = 0.0f;
   m16[7] = 0.0f;
   m16[8] = 0.0f;
   m16[9] = 0.0f;
   m16[10] = 1.0f / (zf - zn);
   m16[11] = 0.0f;
   m16[12] = (l + r) / (l - r);
   m16[13] = (t + b) / (b - t);
   m16[14] = zn / (zn - zf);
   m16[15] = 1.0f;
}

inline void rotationY(const float angle, float* m16)
{
   float c = cosf(angle);
   float s = sinf(angle);

   m16[0] = c;
   m16[1] = 0.0f;
   m16[2] = -s;
   m16[3] = 0.0f;
   m16[4] = 0.0f;
   m16[5] = 1.f;
   m16[6] = 0.0f;
   m16[7] = 0.0f;
   m16[8] = s;
   m16[9] = 0.0f;
   m16[10] = c;
   m16[11] = 0.0f;
   m16[12] = 0.f;
   m16[13] = 0.f;
   m16[14] = 0.f;
   m16[15] = 1.0f;
}

void TransformStart(float* cameraView, float* cameraProjection, float* matrix, bool rightHanded)
{
    if (ImGui::IsKeyPressed(ImGuiKey_T))
        mCurrentGizmoOperation = ImGuizmo::TRANSLATE;
    if (ImGui::IsKeyPressed(ImGuiKey_E))
        mCurrentGizmoOperation = ImGuizmo::ROTATE;
    if (ImGui::IsKeyPressed(ImGuiKey_R)) // r Key
        mCurrentGizmoOperation = ImGuizmo::SCALE;
    bool translateActive = (mCurrentGizmoOperation & ImGuizmo::TRANSLATE) != 0;
    bool rotateActive   = (mCurrentGizmoOperation & ImGuizmo::ROTATE) != 0;
    bool scaleActive    = (mCurrentGizmoOperation & ImGuizmo::SCALE) != 0;
    bool boundsActive   = (mCurrentGizmoOperation & ImGuizmo::BOUNDS) != 0;
    if (ImGui::Checkbox("Translate", &translateActive))
        mCurrentGizmoOperation = (ImGuizmo::OPERATION)((int)mCurrentGizmoOperation ^ (int)ImGuizmo::TRANSLATE);
    ImGui::SameLine();
    if (ImGui::Checkbox("Rotate", &rotateActive))
        mCurrentGizmoOperation = (ImGuizmo::OPERATION)((int)mCurrentGizmoOperation ^ (int)ImGuizmo::ROTATE);
    ImGui::SameLine();
    if (ImGui::Checkbox("Scale", &scaleActive))
        mCurrentGizmoOperation = (ImGuizmo::OPERATION)((int)mCurrentGizmoOperation ^ (int)ImGuizmo::SCALE);
    ImGui::SameLine();
    if (ImGui::Checkbox("Bounds", &boundsActive))
        mCurrentGizmoOperation = (ImGuizmo::OPERATION)((int)mCurrentGizmoOperation ^ (int)ImGuizmo::BOUNDS);
    float matrixTranslation[3], matrixRotation[3], matrixScale[3];
    ImGuizmo::DecomposeMatrixToComponents(matrix, matrixTranslation, matrixRotation, matrixScale);
    ImGui::InputFloat3("Tr", matrixTranslation);
    ImGui::InputFloat3("Rt", matrixRotation);
    ImGui::InputFloat3("Sc", matrixScale);
    ImGuizmo::RecomposeMatrixFromComponents(matrixTranslation, matrixRotation, matrixScale, matrix);

    if (mCurrentGizmoOperation & (ImGuizmo::TRANSLATE | ImGuizmo::ROTATE | ImGuizmo::SCALE))
    {
        if (ImGui::RadioButton("Local", mCurrentGizmoMode == ImGuizmo::LOCAL))
            mCurrentGizmoMode = ImGuizmo::LOCAL;
        ImGui::SameLine();
        if (ImGui::RadioButton("World", mCurrentGizmoMode == ImGuizmo::WORLD))
            mCurrentGizmoMode = ImGuizmo::WORLD;
    }

    if (ImGui::IsKeyPressed(ImGuiKey_S))
        useSnap = !useSnap;
    ImGui::Checkbox("Use Snap", &useSnap);
    ImGui::SameLine();
    if (mCurrentGizmoOperation & ImGuizmo::TRANSLATE)
        ImGui::InputFloat3("Snap", &snap[0]);
    if (mCurrentGizmoOperation & ImGuizmo::ROTATE)
        ImGui::InputFloat("Angle Snap", &snap[0]);
    if (mCurrentGizmoOperation & ImGuizmo::SCALE)
        ImGui::InputFloat("Scale Snap", &snap[0]);
    if (mCurrentGizmoOperation & ImGuizmo::BOUNDS)
    {
        ImGui::InputFloat3("Bounds Min", &bounds[0]);
        ImGui::InputFloat3("Bounds Max", &bounds[3]);
        ImGui::Checkbox("Snap Bounds", &boundSizingSnap);
        if (boundSizingSnap)
            ImGui::InputFloat3("Bounds Snap", &boundsSnap[0]);
    }

    ImGuiIO& io = ImGui::GetIO();
    float viewManipulateRight = io.DisplaySize.x;
    float viewManipulateTop = 0;
    static ImGuiWindowFlags gizmoWindowFlags = 0;
    ImGui::SetNextWindowSize(ImVec2(800, 400), ImGuiCond_Appearing);
    ImGui::SetNextWindowPos(ImVec2(400, 20), ImGuiCond_Appearing);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, (ImVec4)ImColor(0.35f, 0.3f, 0.3f));
    if (useWindow)
    {
       ImGui::Begin("Gizmo", 0, gizmoWindowFlags);
       ImGuizmo::SetDrawlist();
    }
    float windowWidth = (float)ImGui::GetWindowWidth();
    float windowHeight = (float)ImGui::GetWindowHeight();

    if (!useWindow)
    {
       ImGuizmo::SetRect(0, 0, io.DisplaySize.x, io.DisplaySize.y);
    }
    else
    {
       ImGuizmo::SetRect(ImGui::GetWindowPos().x, ImGui::GetWindowPos().y, windowWidth, windowHeight);
    }
    viewManipulateRight = ImGui::GetWindowPos().x + windowWidth;
    viewManipulateTop = ImGui::GetWindowPos().y;
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    gizmoWindowFlags = ImGui::IsWindowHovered() && ImGui::IsMouseHoveringRect(window->InnerRect.Min, window->InnerRect.Max) ? ImGuiWindowFlags_NoMove : 0;

    // Drag in empty viewport area to orbit the camera
    ImGuiIO& ioVP = ImGui::GetIO();
    // Nav-cube rect (top-right corner). Grabbing it moves the view, so it must not also orbit.
    ImRect viewCubeRect(ImVec2(viewManipulateRight - 128, viewManipulateTop), ImVec2(viewManipulateRight, viewManipulateTop + 128));
    static bool orbiting = false;
    if (!ioVP.MouseDown[0])
       orbiting = false;
    else if (ImGui::IsMouseClicked(0) && ImGui::IsWindowHovered() && ImGui::IsMouseHoveringRect(window->InnerRect.Min, window->InnerRect.Max) && !ImGuizmo::IsOver() && !ImGuizmo::IsUsingViewManipulate() && !viewCubeRect.Contains(ioVP.MousePos))
       orbiting = true;
    if (orbiting)
    {
       const float handednessSign = rightHanded ? 1.f : -1.f;
       camYAngle += ioVP.MouseDelta.x * 0.01f * handednessSign;
       camXAngle += ioVP.MouseDelta.y * 0.01f;
       camXAngle = ImClamp(camXAngle, -3.14159f * 0.49f, 3.14159f * 0.49f);
       float eye[] = { cosf(camYAngle) * cosf(camXAngle) * camDistance, sinf(camXAngle) * camDistance, sinf(camYAngle) * cosf(camXAngle) * camDistance };
       float at[] = { 0.f, 0.f, 0.f };
       float up[] = { 0.f, 1.f, 0.f };
       LookAt(eye, at, up, cameraView, rightHanded);
    }

    ImGuizmo::DrawGrid(cameraView, cameraProjection, identityMatrix, 100.f);
    ImGuizmo::DrawCubes(cameraView, cameraProjection, &objectMatrix[0][0], gizmoCount);

    ImGuizmo::PushID("mainView");
    ImGuizmo::ViewManipulate(cameraView, camDistance, ImVec2(viewManipulateRight - 128, viewManipulateTop), ImVec2(128, 128), 0x10101010);
    ImGuizmo::PopID();
}

void TransformEnd()
{
   if (useWindow)
   {
      ImGui::End();
   }
   ImGui::PopStyleColor(1);
}

void EditTransform(float* cameraView, float* cameraProjection, float* matrix)
{
    ImGuiIO& io = ImGui::GetIO();
    float windowWidth = (float)ImGui::GetWindowWidth();
    float windowHeight = (float)ImGui::GetWindowHeight();
    if (!useWindow)
    {
       ImGuizmo::SetRect(0, 0, io.DisplaySize.x, io.DisplaySize.y);
    }
    else
    {
       ImGuizmo::SetRect(ImGui::GetWindowPos().x, ImGui::GetWindowPos().y, windowWidth, windowHeight);
    }
    const bool hasBounds = (mCurrentGizmoOperation & ImGuizmo::BOUNDS) != 0;
    ImGuizmo::Manipulate(cameraView, cameraProjection, mCurrentGizmoOperation, mCurrentGizmoMode, matrix, NULL, useSnap ? &snap[0] : NULL, hasBounds ? bounds : NULL, hasBounds && boundSizingSnap ? boundsSnap : NULL);
}

// Second viewport rendering the same scene through an independent camera.
void SecondView(bool isPerspective, float fov, float viewWidth, bool rightHanded, bool infiniteFarPlane)
{
    static bool firstFrame2 = true;
    static int prevHandedness2 = -1;
    const int handednessNow = rightHanded ? 0 : 1;
    if (prevHandedness2 != handednessNow)
    {
        firstFrame2 = true;
        prevHandedness2 = handednessNow;
    }

    ImGui::SetNextWindowPos(ImVec2(400, 440), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ImVec2(800, 400), ImGuiCond_Appearing);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, (ImVec4)ImColor(0.3f, 0.3f, 0.35f));
    static ImGuiWindowFlags secondViewFlags = 0;
    ImGui::Begin("Second View", &useSecondView, secondViewFlags);
    ImGuizmo::SetDrawlist();

    ImVec2 winPos = ImGui::GetWindowPos();
    float winWidth = (float)ImGui::GetWindowWidth();
    float winHeight = (float)ImGui::GetWindowHeight();
    ImGuizmo::SetRect(winPos.x, winPos.y, winWidth, winHeight);

    // Projection built from this viewport aspect ratio
    float cameraProjection2[16];
    if (isPerspective)
    {
        Perspective(fov, winWidth / winHeight, 0.1f, 100.f, cameraProjection2, rightHanded, infiniteFarPlane);
    }
    else
    {
        float viewHeight = viewWidth * winHeight / winWidth;
        float zn = rightHanded ? 1000.f : -1000.f;
        float zf = rightHanded ? -1000.f : 1000.f;
        OrthoGraphic(-viewWidth, viewWidth, -viewHeight, viewHeight, zn, zf, cameraProjection2);
    }
    ImGuizmo::SetOrthographic(!isPerspective);

    ImGuiIO& io = ImGui::GetIO();
    ImGuiWindow* window2 = ImGui::GetCurrentWindow();
    // Prevent moving the window when dragging over its content (mirrors the 'Gizmo' view)
    secondViewFlags = ImGui::IsWindowHovered() && ImGui::IsMouseHoveringRect(window2->InnerRect.Min, window2->InnerRect.Max) ? ImGuiWindowFlags_NoMove : 0;
    bool viewDirty2 = firstFrame2;
    // Drag in empty viewport area to orbit the second camera
    ImRect viewCubeRect2(ImVec2(winPos.x + winWidth - 128, winPos.y), ImVec2(winPos.x + winWidth, winPos.y + 128));
    static bool orbiting2 = false;
    if (!io.MouseDown[0])
        orbiting2 = false;
    else if (ImGui::IsMouseClicked(0) && ImGui::IsWindowHovered() && ImGui::IsMouseHoveringRect(window2->InnerRect.Min, window2->InnerRect.Max) && !ImGuizmo::IsOver() && !ImGuizmo::IsUsingViewManipulate() && !viewCubeRect2.Contains(io.MousePos))
        orbiting2 = true;
    if (orbiting2)
    {
        const float handednessSign = rightHanded ? 1.f : -1.f;
        camYAngle2 += io.MouseDelta.x * 0.01f * handednessSign;
        camXAngle2 += io.MouseDelta.y * 0.01f;
        camXAngle2 = ImClamp(camXAngle2, -3.14159f * 0.49f, 3.14159f * 0.49f);
        viewDirty2 = true;
    }
    if (viewDirty2)
    {
        float eye[] = { cosf(camYAngle2) * cosf(camXAngle2) * camDistance2, sinf(camXAngle2) * camDistance2, sinf(camYAngle2) * cosf(camXAngle2) * camDistance2 };
        float at[] = { 0.f, 0.f, 0.f };
        float up[] = { 0.f, 1.f, 0.f };
        LookAt(eye, at, up, cameraView2, rightHanded);
        firstFrame2 = false;
    }

    ImGuizmo::DrawGrid(cameraView2, cameraProjection2, identityMatrix, 100.f);
    ImGuizmo::DrawCubes(cameraView2, cameraProjection2, &objectMatrix[0][0], gizmoCount);

    const bool hasBounds = (mCurrentGizmoOperation & ImGuizmo::BOUNDS) != 0;
    // distinct ID scope so this viewport's gizmo handles don't collide with the main one
    ImGuizmo::PushID("view2");
    for (int matId = 0; matId < gizmoCount; matId++)
    {
        ImGuizmo::PushID(matId);
        ImGuizmo::Enable(gizmoEnabled[matId]);
        ImGuizmo::SetRect(winPos.x, winPos.y, winWidth, winHeight);
        ImGuizmo::Manipulate(cameraView2, cameraProjection2, mCurrentGizmoOperation, mCurrentGizmoMode, objectMatrix[matId], NULL, useSnap ? &snap[0] : NULL, hasBounds ? bounds : NULL, hasBounds && boundSizingSnap ? boundsSnap : NULL);
        ImGuizmo::PopID();
    }
    ImGuizmo::PopID();

    ImGuizmo::PushID("secondView");
    ImGuizmo::ViewManipulate(cameraView2, camDistance2, ImVec2(winPos.x + winWidth - 128, winPos.y), ImVec2(128, 128), 0x10101010);
    ImGuizmo::PopID();

    ImGui::End();
    ImGui::PopStyleColor(1);
}

//
//
// ImSequencer interface
//
//
static const char* SequencerItemTypeNames[] = { "Camera","Music", "ScreenEffect", "FadeIn", "Animation" };

struct RampEdit : public ImCurveEdit::Delegate
{
   RampEdit()
   {
      mPts[0][0] = ImVec2(-10.f, 0);
      mPts[0][1] = ImVec2(20.f, 0.6f);
      mPts[0][2] = ImVec2(25.f, 0.2f);
      mPts[0][3] = ImVec2(70.f, 0.4f);
      mPts[0][4] = ImVec2(120.f, 1.f);
      mPointCount[0] = 5;

      mPts[1][0] = ImVec2(-50.f, 0.2f);
      mPts[1][1] = ImVec2(33.f, 0.7f);
      mPts[1][2] = ImVec2(80.f, 0.2f);
      mPts[1][3] = ImVec2(82.f, 0.8f);
      mPointCount[1] = 4;


      mPts[2][0] = ImVec2(40.f, 0);
      mPts[2][1] = ImVec2(60.f, 0.1f);
      mPts[2][2] = ImVec2(90.f, 0.82f);
      mPts[2][3] = ImVec2(150.f, 0.24f);
      mPts[2][4] = ImVec2(200.f, 0.34f);
      mPts[2][5] = ImVec2(250.f, 0.12f);
      mPointCount[2] = 6;
      mbVisible[0] = mbVisible[1] = mbVisible[2] = true;
      mMax = ImVec2(1.f, 1.f);
      mMin = ImVec2(0.f, 0.f);
   }
   size_t GetCurveCount()
   {
      return 3;
   }

   bool IsVisible(size_t curveIndex)
   {
      return mbVisible[curveIndex];
   }
   size_t GetPointCount(size_t curveIndex)
   {
      return mPointCount[curveIndex];
   }

   uint32_t GetCurveColor(size_t curveIndex)
   {
      uint32_t cols[] = { 0xFF0000FF, 0xFF00FF00, 0xFFFF0000 };
      return cols[curveIndex];
   }
   ImVec2* GetPoints(size_t curveIndex)
   {
      return mPts[curveIndex];
   }
   virtual ImCurveEdit::CurveType GetCurveType(size_t curveIndex) const { return ImCurveEdit::CurveSmooth; }
   virtual int EditPoint(size_t curveIndex, int pointIndex, ImVec2 value)
   {
      mPts[curveIndex][pointIndex] = ImVec2(value.x, value.y);
      SortValues(curveIndex);
      for (size_t i = 0; i < GetPointCount(curveIndex); i++)
      {
         if (mPts[curveIndex][i].x == value.x)
            return (int)i;
      }
      return pointIndex;
   }
   virtual void AddPoint(size_t curveIndex, ImVec2 value)
   {
      if (mPointCount[curveIndex] >= 8)
         return;
      mPts[curveIndex][mPointCount[curveIndex]++] = value;
      SortValues(curveIndex);
   }
   virtual ImVec2& GetMax() { return mMax; }
   virtual ImVec2& GetMin() { return mMin; }
   virtual unsigned int GetBackgroundColor() { return 0; }
   ImVec2 mPts[3][8];
   size_t mPointCount[3];
   bool mbVisible[3];
   ImVec2 mMin;
   ImVec2 mMax;
private:
   void SortValues(size_t curveIndex)
   {
      auto b = std::begin(mPts[curveIndex]);
      auto e = std::begin(mPts[curveIndex]) + GetPointCount(curveIndex);
      std::sort(b, e, [](ImVec2 a, ImVec2 b) { return a.x < b.x; });

   }
};

struct MySequence : public ImSequencer::SequenceInterface
{
   // interface with sequencer

   virtual int GetFrameMin() const {
      return mFrameMin;
   }
   virtual int GetFrameMax() const {
      return mFrameMax;
   }
   virtual int GetItemCount() const { return (int)myItems.size(); }

   virtual int GetItemTypeCount() const { return sizeof(SequencerItemTypeNames) / sizeof(char*); }
   virtual const char* GetItemTypeName(int typeIndex) const { return SequencerItemTypeNames[typeIndex]; }
   virtual const char* GetItemLabel(int index) const
   {
      static char tmps[512];
      snprintf(tmps, 512, "[%02d] %s", index, SequencerItemTypeNames[myItems[index].mType]);
      return tmps;
   }

   virtual void Get(int index, int** start, int** end, int* type, unsigned int* color)
   {
      MySequenceItem& item = myItems[index];
      if (color)
         *color = 0xFFAA8080; // same color for everyone, return color based on type
      if (start)
         *start = &item.mFrameStart;
      if (end)
         *end = &item.mFrameEnd;
      if (type)
         *type = item.mType;
   }
   virtual void Add(int type) { myItems.push_back(MySequenceItem{ type, 0, 10, false }); };
   virtual void Del(int index) { myItems.erase(myItems.begin() + index); }
   virtual void Duplicate(int index) { myItems.push_back(myItems[index]); }

   virtual size_t GetCustomHeight(int index) { return myItems[index].mExpanded ? 300 : 0; }

   // my datas
   MySequence() : mFrameMin(0), mFrameMax(0) {}
   int mFrameMin, mFrameMax;
   struct MySequenceItem
   {
      int mType;
      int mFrameStart, mFrameEnd;
      bool mExpanded;
   };
   std::vector<MySequenceItem> myItems;
   RampEdit rampEdit;

   virtual void DoubleClick(int index) {
      if (myItems[index].mExpanded)
      {
         myItems[index].mExpanded = false;
         return;
      }
      for (auto& item : myItems)
         item.mExpanded = false;
      myItems[index].mExpanded = !myItems[index].mExpanded;
   }

   virtual void CustomDraw(int index, ImDrawList* draw_list, const ImRect& rc, const ImRect& legendRect, const ImRect& clippingRect, const ImRect& legendClippingRect)
   {
      static const char* labels[] = { "Translation", "Rotation" , "Scale" };

      rampEdit.mMax = ImVec2(float(mFrameMax), 1.f);
      rampEdit.mMin = ImVec2(float(mFrameMin), 0.f);
      draw_list->PushClipRect(legendClippingRect.Min, legendClippingRect.Max, true);
      for (int i = 0; i < 3; i++)
      {
         ImVec2 pta(legendRect.Min.x + 30, legendRect.Min.y + i * 14.f);
         ImVec2 ptb(legendRect.Max.x, legendRect.Min.y + (i + 1) * 14.f);
         draw_list->AddText(pta, rampEdit.mbVisible[i] ? 0xFFFFFFFF : 0x80FFFFFF, labels[i]);
         if (ImRect(pta, ptb).Contains(ImGui::GetMousePos()) && ImGui::IsMouseClicked(0))
            rampEdit.mbVisible[i] = !rampEdit.mbVisible[i];
      }
      draw_list->PopClipRect();

      ImGui::SetCursorScreenPos(rc.Min);
      ImCurveEdit::Edit(rampEdit, rc.Max - rc.Min, 137 + index, &clippingRect);
   }

   virtual void CustomDrawCompact(int index, ImDrawList* draw_list, const ImRect& rc, const ImRect& clippingRect)
   {
      rampEdit.mMax = ImVec2(float(mFrameMax), 1.f);
      rampEdit.mMin = ImVec2(float(mFrameMin), 0.f);
      draw_list->PushClipRect(clippingRect.Min, clippingRect.Max, true);
      for (int i = 0; i < 3; i++)
      {
         for (unsigned int j = 0; j < rampEdit.mPointCount[i]; j++)
         {
            float p = rampEdit.mPts[i][j].x;
            if (p < myItems[index].mFrameStart || p > myItems[index].mFrameEnd)
               continue;
            float r = (p - mFrameMin) / float(mFrameMax - mFrameMin);
            float x = ImLerp(rc.Min.x, rc.Max.x, r);
            draw_list->AddLine(ImVec2(x, rc.Min.y + 6), ImVec2(x, rc.Max.y - 4), 0xAA000000, 4.f);
         }
      }
      draw_list->PopClipRect();
   }
};

//
//
// GraphEditor interface
//
//


template <typename T, std::size_t N>
struct Array
{
   T data[N];
   const size_t size() const { return N; }

   const T operator [] (size_t index) const { return data[index]; }
   operator T* () {
      T* p = new T[N];
      memcpy(p, data, sizeof(data));
      return p;
   }
};

template <typename T, typename ... U> Array(T, U...)->Array<T, 1 + sizeof...(U)>;

struct GraphEditorDelegate : public GraphEditor::Delegate
{
   bool AllowedLink(GraphEditor::NodeIndex from, GraphEditor::NodeIndex to) override
   {
      return true;
   }

   void SelectNode(GraphEditor::NodeIndex nodeIndex, bool selected) override
   {
      mNodes[nodeIndex].mSelected = selected;
   }

   void MoveSelectedNodes(const ImVec2 delta) override
   {
      for (auto& node : mNodes)
      {
         if (!node.mSelected)
         {
            continue;
         }
         node.x += delta.x;
         node.y += delta.y;
      }
   }

   virtual void RightClick(GraphEditor::NodeIndex nodeIndex, GraphEditor::SlotIndex slotIndexInput, GraphEditor::SlotIndex slotIndexOutput) override
   {
   }

   void AddLink(GraphEditor::NodeIndex inputNodeIndex, GraphEditor::SlotIndex inputSlotIndex, GraphEditor::NodeIndex outputNodeIndex, GraphEditor::SlotIndex outputSlotIndex) override
   {
      mLinks.push_back({ inputNodeIndex, inputSlotIndex, outputNodeIndex, outputSlotIndex });
   }

   void DelLink(GraphEditor::LinkIndex linkIndex) override
   {
      mLinks.erase(mLinks.begin() + linkIndex);
   }

   void CustomDraw(ImDrawList* drawList, ImRect rectangle, GraphEditor::NodeIndex nodeIndex) override
   {
      drawList->AddLine(rectangle.Min, rectangle.Max, IM_COL32(0, 0, 0, 255));
      drawList->AddText(rectangle.Min, IM_COL32(255, 128, 64, 255), "Draw");
   }

   const size_t GetTemplateCount() override
   {
      return sizeof(mTemplates) / sizeof(GraphEditor::Template);
   }

   const GraphEditor::Template GetTemplate(GraphEditor::TemplateIndex index) override
   {
      return mTemplates[index];
   }

   const size_t GetNodeCount() override
   {
      return mNodes.size();
   }

   const GraphEditor::Node GetNode(GraphEditor::NodeIndex index) override
   {
      const auto& myNode = mNodes[index];
      return GraphEditor::Node
      {
          myNode.name,
          myNode.templateIndex,
          ImRect(ImVec2(myNode.x, myNode.y), ImVec2(myNode.x + 200, myNode.y + 200)),
          myNode.mSelected
      };
   }

   const size_t GetLinkCount() override
   {
      return mLinks.size();
   }

   const GraphEditor::Link GetLink(GraphEditor::LinkIndex index) override
   {
      return mLinks[index];
   }

   // Graph datas
   static const inline GraphEditor::Template mTemplates[] = {
       {
           IM_COL32(160, 160, 180, 255),
           IM_COL32(100, 100, 140, 255),
           IM_COL32(110, 110, 150, 255),
           1,
           Array{"MyInput"},
           nullptr,
           2,
           Array{"MyOutput0", "MyOuput1"},
           nullptr
       },

       {
           IM_COL32(180, 160, 160, 255),
           IM_COL32(140, 100, 100, 255),
           IM_COL32(150, 110, 110, 255),
           3,
           nullptr,
           Array{ IM_COL32(200,100,100,255), IM_COL32(100,200,100,255), IM_COL32(100,100,200,255) },
           1,
           Array{"MyOutput0"},
           Array{ IM_COL32(200,200,200,255)}
       }
   };

   struct Node
   {
      const char* name;
      GraphEditor::TemplateIndex templateIndex;
      float x, y;
      bool mSelected;
   };

   std::vector<Node> mNodes = {
       {
           "My Node 0",
           0,
           0, 0,
           false
       },

       {
           "My Node 1",
           0,
           400, 0,
           false
       },

       {
           "My Node 2",
           1,
           400, 400,
           false
       }
   };

   std::vector<GraphEditor::Link> mLinks = { {0, 0, 1, 0} };
};

//
//
// ImVectorEditor demo
//
//

static void SeedVectorEditorPath(ImVectorEditor::Path& path, ImVectorEditor::Editor& editor)
{
   path.clear();

   ImVectorEditor::Anchor a;
   a.position = ImVec2(0.0f, 0.0f);
   a.handleOut = ImVec2(70.0f, -90.0f);
   a.hasHandleOut = true;

   ImVectorEditor::Anchor b;
   b.position = ImVec2(180.0f, 0.0f);
   b.handleIn = ImVec2(-70.0f, -90.0f);
   b.handleOut = ImVec2(60.0f, 90.0f);
   b.hasHandleIn = true;
   b.hasHandleOut = true;
   b.handleMode = ImVectorEditor::HandleMode::Free;

   ImVectorEditor::Anchor c;
   c.position = ImVec2(320.0f, 120.0f);
   c.handleIn = ImVec2(-60.0f, 90.0f);
   c.hasHandleIn = true;

   path.anchors = { a, b, c };
   path.closed = false;
   editor.ClearSelection();
}

static void ControlPointShapeCombo(const char* label, ImVectorEditor::ControlPointShape& shape)
{
   const char* shapes[] = { "Circle", "Square", "Diamond" };
   int shapeIndex = static_cast<int>(shape);
   if (ImGui::Combo(label, &shapeIndex, shapes, IM_ARRAYSIZE(shapes)))
      shape = static_cast<ImVectorEditor::ControlPointShape>(shapeIndex);
}

static const char* VectorEditorEditKindName(ImVectorEditor::EditKind kind)
{
   switch (kind)
   {
   case ImVectorEditor::EditKind::MoveAnchor: return "Move Anchor";
   case ImVectorEditor::EditKind::MoveHandle: return "Move Handle";
   case ImVectorEditor::EditKind::AddAnchor: return "Add Anchor";
   case ImVectorEditor::EditKind::DeleteAnchor: return "Delete Anchor";
   case ImVectorEditor::EditKind::AddHandle: return "Add Handles";
   case ImVectorEditor::EditKind::DeleteHandle: return "Delete Handles";
   case ImVectorEditor::EditKind::ChangePointMode: return "Change Point Mode";
   case ImVectorEditor::EditKind::PathOperation: return "Path Operation";
   }
   return "Edit";
}

struct VectorEditorUndoDebug : ImVectorEditor::Delegate
{
   int editCount = 0;
   int activeAnchor = -1;
   const char* activeEdit = "None";
   const char* lastEdit = "None";

   void BeginEdit(ImVectorEditor::EditKind kind, int anchorIndex) override
   {
      activeAnchor = anchorIndex;
      activeEdit = VectorEditorEditKindName(kind);
   }

   void EndEdit() override
   {
      ++editCount;
      lastEdit = activeEdit;
      activeEdit = "None";
      activeAnchor = -1;
   }
};

static ImVec2 VectorEditorPathCenter(const ImVectorEditor::Path& path)
{
   if (path.anchors.empty())
      return ImVec2(0.0f, 0.0f);

   ImVec2 minPos = path.anchors.front().position;
   ImVec2 maxPos = path.anchors.front().position;
   for (const ImVectorEditor::Anchor& anchor : path.anchors)
   {
      minPos.x = std::min(minPos.x, anchor.position.x);
      minPos.y = std::min(minPos.y, anchor.position.y);
      maxPos.x = std::max(maxPos.x, anchor.position.x);
      maxPos.y = std::max(maxPos.y, anchor.position.y);
   }
   return ImVec2((minPos.x + maxPos.x) * 0.5f, (minPos.y + maxPos.y) * 0.5f);
}

static void ApplyVectorEditorViewResult(const ImVectorEditor::Result& result,
   ImVectorEditor::Config& config)
{
   config.transform.pan.x += result.viewPanDelta.x;
   config.transform.pan.y += result.viewPanDelta.y;

   if (result.viewZoomFactor != 1.0f)
   {
      const float oldZoom = config.transform.zoom;
      const float newZoom = std::max(0.25f, std::min(oldZoom * result.viewZoomFactor, 4.0f));
      const float appliedFactor = newZoom / oldZoom;
      const ImVec2 center = result.viewZoomCenterCanvas;
      config.transform.pan = ImVec2(
         center.x - (center.x - config.transform.pan.x) * appliedFactor,
         center.y - (center.y - config.transform.pan.y) * appliedFactor);
      config.transform.zoom = newZoom;
   }
}

static void ShowVectorEditorDemo()
{
   static ImVectorEditor::Editor editor;
   static ImVectorEditor::Path path;
   static ImVectorEditor::Config config;
   static ImVectorEditor::Tool tool = ImVectorEditor::Tool::Select;
   static VectorEditorUndoDebug undoDebug;
   static bool initialized = false;

   config.delegate = &undoDebug;

   if (!initialized)
   {
      initialized = true;
      config.transform.pan = ImVec2(80.0f, 90.0f);
      config.canvasSize = ImVec2(0.0f, 320.0f);
      SeedVectorEditorPath(path, editor);
   }

   if (ImGui::RadioButton("Select##VectorEditor", tool == ImVectorEditor::Tool::Select))
      tool = ImVectorEditor::Tool::Select;
   ImGui::SameLine();
   if (ImGui::RadioButton("Pen##VectorEditor", tool == ImVectorEditor::Tool::Pen))
      tool = ImVectorEditor::Tool::Pen;
   ImGui::SameLine();
   if (ImGui::Button("Clear##VectorEditor"))
   {
      undoDebug.BeginEdit(ImVectorEditor::EditKind::PathOperation, -1);
      path.clear();
      editor.ClearSelection();
      tool = ImVectorEditor::Tool::Select;
      undoDebug.EndEdit();
   }
   ImGui::SameLine();
   if (ImGui::Button("Seed##VectorEditor"))
   {
      SeedVectorEditorPath(path, editor);
      tool = ImVectorEditor::Tool::Select;
   }

   const int selectedAnchor = editor.GetSelectedAnchor();
   const bool hasSelection = selectedAnchor >= 0 && selectedAnchor < static_cast<int>(path.anchors.size());
   const ImVectorEditor::HandleMode selectedMode = hasSelection
      ? path.anchors[selectedAnchor].handleMode
      : ImVectorEditor::HandleMode::Corner;
   if (ImGui::RadioButton("Corner##VectorEditor", selectedMode == ImVectorEditor::HandleMode::Corner) && hasSelection)
   {
      undoDebug.BeginEdit(path.anchors[selectedAnchor].hasHandleIn || path.anchors[selectedAnchor].hasHandleOut
         ? ImVectorEditor::EditKind::DeleteHandle
         : ImVectorEditor::EditKind::ChangePointMode, selectedAnchor);
      ImVectorEditor::MakeCorner(path.anchors[selectedAnchor]);
      undoDebug.EndEdit();
   }
   ImGui::SameLine();
   if (ImGui::RadioButton("Aligned##VectorEditor", selectedMode == ImVectorEditor::HandleMode::Aligned) && hasSelection)
   {
      undoDebug.BeginEdit(!path.anchors[selectedAnchor].hasHandleIn && !path.anchors[selectedAnchor].hasHandleOut
         ? ImVectorEditor::EditKind::AddHandle
         : ImVectorEditor::EditKind::ChangePointMode, selectedAnchor);
      ImVectorEditor::MakeAligned(path.anchors[selectedAnchor]);
      undoDebug.EndEdit();
   }
   ImGui::SameLine();
   if (ImGui::RadioButton("Mirrored##VectorEditor", selectedMode == ImVectorEditor::HandleMode::Mirrored) && hasSelection)
   {
      undoDebug.BeginEdit(!path.anchors[selectedAnchor].hasHandleIn && !path.anchors[selectedAnchor].hasHandleOut
         ? ImVectorEditor::EditKind::AddHandle
         : ImVectorEditor::EditKind::ChangePointMode, selectedAnchor);
      ImVectorEditor::MakeMirrored(path.anchors[selectedAnchor]);
      undoDebug.EndEdit();
   }
   ImGui::SameLine();
   if (ImGui::Button("Add Handles##VectorEditor") && hasSelection)
   {
      undoDebug.BeginEdit(ImVectorEditor::EditKind::AddHandle, selectedAnchor);
      ImVectorEditor::AddHandles(path.anchors[selectedAnchor]);
      undoDebug.EndEdit();
   }
   ImGui::SameLine();
   if (ImGui::Button("Delete Handles##VectorEditor") && hasSelection)
   {
      undoDebug.BeginEdit(ImVectorEditor::EditKind::DeleteHandle, selectedAnchor);
      ImVectorEditor::DeleteHandles(path.anchors[selectedAnchor]);
      undoDebug.EndEdit();
   }

   if (ImGui::TreeNodeEx("Path##VectorEditor"))
   {
      if (ImGui::Button(path.closed ? "Open Path##VectorEditor" : "Close Path##VectorEditor"))
      {
         undoDebug.BeginEdit(ImVectorEditor::EditKind::PathOperation, -1);
         path.closed = !path.closed;
         undoDebug.EndEdit();
      }
      ImGui::SameLine();
      if (ImGui::Button("Reverse Path##VectorEditor"))
      {
         undoDebug.BeginEdit(ImVectorEditor::EditKind::PathOperation, -1);
         ImVectorEditor::ReversePath(path);
         undoDebug.EndEdit();
      }
      ImGui::Text("Selected anchor: %d (%d selected)",
         selectedAnchor, editor.GetSelectedAnchorCount());
      ImGui::TreePop();
   }

   if (editor.GetSelectedAnchorCount() == static_cast<int>(path.anchors.size()) && !path.anchors.empty())
      config.transform.objectPivot = VectorEditorPathCenter(path);
   else if (hasSelection)
      config.transform.objectPivot = path.anchors[selectedAnchor].position;
   else
      config.transform.objectPivot = VectorEditorPathCenter(path);

   if (ImGui::TreeNodeEx("View##VectorEditor"))
   {
      ImGui::DragFloat2("Pan##VectorEditor", &config.transform.pan.x, 1.0f);
      ImGui::SliderFloat("Zoom##VectorEditor", &config.transform.zoom, 0.25f, 4.0f, "%.2f");
      ImGui::SliderAngle("Rotation##VectorEditor", &config.transform.objectRotationRadians, -180.0f, 180.0f);
      ImGui::Text("Rotation pivot: %.1f, %.1f",
         config.transform.objectPivot.x, config.transform.objectPivot.y);
      ImGui::TreePop();
   }

   if (ImGui::TreeNodeEx("Style##VectorEditor"))
   {
      ImGui::Checkbox("Show Grid##VectorEditor", &config.showGrid);
      ImGui::SliderFloat("Grid Step##VectorEditor", &config.style.gridStep, 8.0f, 96.0f, "%.1f");
      ImGui::SliderFloat("Path Thickness##VectorEditor", &config.style.pathThickness, 1.0f, 8.0f, "%.1f");
      ImGui::SliderFloat("Handle Line Thickness##VectorEditor", &config.style.handleLineThickness, 0.5f, 4.0f, "%.1f");
      ImGui::SliderFloat("Anchor Size##VectorEditor", &config.style.anchorRadius, 2.0f, 12.0f, "%.1f");
      ImGui::SliderFloat("Handle Size##VectorEditor", &config.style.handleRadius, 2.0f, 10.0f, "%.1f");
      ControlPointShapeCombo("Anchor Shape##VectorEditor", config.style.anchorShape);
      ControlPointShapeCombo("Handle Shape##VectorEditor", config.style.handleShape);
      ImGui::SliderFloat("Hit Radius##VectorEditor", &config.style.hitRadius, 4.0f, 20.0f, "%.1f");
      ImGui::TreePop();
   }

   config.tool = tool;
   config.canvasSize.x = ImGui::GetContentRegionAvail().x;
   const ImVectorEditor::Result result = editor.Draw("##ImVectorEditor", path, config);
   ApplyVectorEditorViewResult(result, config);

   ImGui::Text("changed=%s committed=%s capture mouse=%s keyboard=%s",
      result.changed ? "true" : "false",
      result.committed ? "true" : "false",
      editor.WantsMouseCapture() ? "true" : "false",
      editor.WantsKeyboardCapture() ? "true" : "false");
   ImGui::Text("undo steps=%d last=%s active=%s anchor=%d",
      undoDebug.editCount, undoDebug.lastEdit, undoDebug.activeEdit, undoDebug.activeAnchor);
   ImGui::TextWrapped("Select: drag anchors/handles, Shift-click or box-select anchors, Delete removes selection. Mouse wheel zooms, middle mouse pans. Pen: click anchors, click-drag handles, hold Shift while dragging to snap handles to 45 degrees, click first anchor to close.");
}


// Regression self-test for issue #423 (gizmo jitter on hover/drag of translate planes).
// Uses the exact matrices from the issue (view has no translation, model ~11 units away,
// reversed-Z near-infinite perspective) and a literal mouse position, so it needs no mouse
// input. It exercises ImGuizmo's real picking-ray computation and checks the resulting
// world-space plane hit stays precise in float. Before the fix the ray origin sat on the
// far plane (~1e4 units away / infinity), causing catastrophic float cancellation.
static bool GizmoRaycastSelfTest()
{
   // ImGuizmo column-major m16 layout (the issue printed the matrices column-vector style).
   const float view[16] = {
       -0.113034f,  0.481454f,  0.869152f, 0.f,
       -0.085660f,  0.866780f, -0.491280f, 0.f,
       -0.989892f, -0.129983f, -0.056735f, 0.f,
        0.f,        0.f,        0.f,        1.f };
   const float proj[16] = {
       1.428148f, 0.f,       0.f,  0.f,
       0.f,       2.794813f, 0.f,  0.f,
       0.f,       0.f,       0.f, -1.f,
       0.f,       0.f,       0.1f, 0.f };
   const float model[16] = {
       -0.192083f,   0.f,        -0.981379f, 0.f,
        0.720528f,   0.678933f,  -0.141027f, 0.f,
        0.666290f,  -0.734200f,  -0.130411f, 0.f,
      -10.263045f,   5.331280f,   0.555734f, 1.f };
   const float modelPos[3] = { model[12], model[13], model[14] };

   const ImVec2 rectPos(0.f, 0.f), rectSize(1957.f, 1000.f);

   // view * proj (row-vector convention, m16[row*4+col]).
   float vp[16];
   for (int i = 0; i < 4; i++)
       for (int j = 0; j < 4; j++)
       {
           float s = 0.f;
           for (int k = 0; k < 4; k++) s += view[i * 4 + k] * proj[k * 4 + j];
           vp[i * 4 + j] = s;
       }
   // Project the gizmo center to a screen-space mouse position.
   float c[4];
   for (int j = 0; j < 4; j++)
       c[j] = modelPos[0] * vp[0 * 4 + j] + modelPos[1] * vp[1 * 4 + j] + modelPos[2] * vp[2 * 4 + j] + vp[3 * 4 + j];
   const float ndcx = c[0] / c[3], ndcy = c[1] / c[3];
   const ImVec2 mouse((ndcx * 0.5f + 0.5f) * rectSize.x + rectPos.x,
                      (1.f - (ndcy * 0.5f + 0.5f)) * rectSize.y + rectPos.y);

   float o[3], d[3];
   ImGuizmo::ComputeMouseRay(view, proj, mouse, rectPos, rectSize, o, d);

   // Intersect the ray with the XY plane (normal +Z through the gizmo position).
   const float n[3] = { 0.f, 0.f, 1.f };
   const float planeW = n[0] * modelPos[0] + n[1] * modelPos[1] + n[2] * modelPos[2];
   const float denom = n[0] * d[0] + n[1] * d[1] + n[2] * d[2];
   const float len = -((n[0] * o[0] + n[1] * o[1] + n[2] * o[2]) - planeW) / denom;
   const float hit[3] = { o[0] + d[0] * len, o[1] + d[1] * len, o[2] + d[2] * len };
   const float err = sqrtf((hit[0] - modelPos[0]) * (hit[0] - modelPos[0]) +
                           (hit[1] - modelPos[1]) * (hit[1] - modelPos[1]) +
                           (hit[2] - modelPos[2]) * (hit[2] - modelPos[2]));
   const float originMag = sqrtf(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]);

   const bool pass = (originMag < 1.f) && (err < 1e-2f);
   printf("[GizmoRaycastSelfTest] rayOrigin=(%.5f, %.5f, %.5f) mag=%.5f\n", o[0], o[1], o[2], originMag);
   printf("[GizmoRaycastSelfTest] planeHit=(%.5f, %.5f, %.5f) expected=(%.5f, %.5f, %.5f) err=%.6f\n",
       hit[0], hit[1], hit[2], modelPos[0], modelPos[1], modelPos[2], err);
   printf("[GizmoRaycastSelfTest] %s\n", pass ? "PASS" : "FAIL");
   fflush(stdout);
   return pass;
}

int main(int, char**)
{
   ImApp::ImApp imApp;

   ImApp::Config config;
   config.mWidth = 1280;
   config.mHeight = 720;
   //config.mFullscreen = true;
   imApp.Init(config);

   GizmoRaycastSelfTest();

   int lastUsing = 0;

   float cameraView[16] =
   { 1.f, 0.f, 0.f, 0.f,
     0.f, 1.f, 0.f, 0.f,
     0.f, 0.f, 1.f, 0.f,
     0.f, 0.f, 0.f, 1.f };

   float cameraProjection[16];

   // build a procedural texture. Copy/pasted and adapted from https://rosettacode.org/wiki/Plasma_effect#Graphics_version
   unsigned int procTexture;
   glGenTextures(1, &procTexture);
   glBindTexture(GL_TEXTURE_2D, procTexture);
   uint32_t* tempBitmap = new uint32_t[256 * 256];
   int index = 0;
   for (int y = 0; y < 256; y++)
   {
      for (int x = 0; x < 256; x++)
      {
         float dx = x + .5f;
         float dy = y + .5f;
         float dv = sinf(x * 0.02f) + sinf(0.03f * (x + y)) + sinf(sqrtf(0.4f * (dx * dx + dy * dy) + 1.f));

         tempBitmap[index] = 0xFF000000 +
         (int(255 * fabsf(sinf(dv * 3.141592f))) << 16) +
         (int(255 * fabsf(sinf(dv * 3.141592f + 2 * 3.141592f / 3))) << 8) + 
         (int(255 * fabs(sin(dv * 3.141592f + 4.f * 3.141592f / 3.f))));

         index++;
      }
   }
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, tempBitmap);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   delete [] tempBitmap;

   // sequence with default values
   MySequence mySequence;
   mySequence.mFrameMin = -100;
   mySequence.mFrameMax = 1000;
   mySequence.myItems.push_back(MySequence::MySequenceItem{ 0, 10, 30, false });
   mySequence.myItems.push_back(MySequence::MySequenceItem{ 1, 20, 30, true });
   mySequence.myItems.push_back(MySequence::MySequenceItem{ 3, 12, 60, false });
   mySequence.myItems.push_back(MySequence::MySequenceItem{ 2, 61, 90, false });
   mySequence.myItems.push_back(MySequence::MySequenceItem{ 4, 90, 99, false });

   // Camera projection
   bool isPerspective = true;
   float fov = 27.f;
   float viewWidth = 10.f; // for orthographic
   bool infiniteFarPlane = false;
   int handedness = 0; // 0 = right-handed, 1 = left-handed

   bool firstFrame = true;

   // Main loop
   while (!imApp.Done())
   {
      imApp.NewFrame();

      ImGuiIO& io = ImGui::GetIO();
      bool rightHanded = (handedness == 0);
      if (isPerspective)
      {
         Perspective(fov, io.DisplaySize.x / io.DisplaySize.y, 0.1f, 100.f, cameraProjection, rightHanded, infiniteFarPlane);
      }
      else
      {
         float viewHeight = viewWidth * io.DisplaySize.y / io.DisplaySize.x;
         float zn = rightHanded ? 1000.f : -1000.f;
         float zf = rightHanded ? -1000.f : 1000.f;
         OrthoGraphic(-viewWidth, viewWidth, -viewHeight, viewHeight, zn, zf, cameraProjection);
      }
      ImGuizmo::SetOrthographic(!isPerspective);
      ImGuizmo::BeginFrame();

      ImGui::SetNextWindowPos(ImVec2(1024, 100), ImGuiCond_Appearing);
      ImGui::SetNextWindowSize(ImVec2(256, 256), ImGuiCond_Appearing);

      // create a window and insert the inspector
      ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_Appearing);
      ImGui::SetNextWindowSize(ImVec2(320, 500), ImGuiCond_Appearing);
      ImGui::Begin("Editor");
      if (ImGui::RadioButton("Full view", !useWindow)) useWindow = false;
      ImGui::SameLine();
      if (ImGui::RadioButton("Window", useWindow)) useWindow = true;

      ImGui::Text("Camera");
      bool viewDirty = false;
      if (ImGui::RadioButton("Perspective", isPerspective)) isPerspective = true;
      ImGui::SameLine();
      if (ImGui::RadioButton("Orthographic", !isPerspective)) isPerspective = false;
      if (isPerspective)
      {
         ImGui::SliderFloat("Fov", &fov, 20.f, 110.f);
      }
      else
      {
         ImGui::SliderFloat("Ortho width", &viewWidth, 1, 20);
      }
      viewDirty |= ImGui::SliderFloat("Distance", &camDistance, 1.f, 10.f);
      if (ImGui::IsItemHovered() && io.MouseWheel != 0.f)
      {
         camDistance = ImClamp(camDistance - io.MouseWheel * 0.5f, 1.f, 10.f);
         viewDirty = true;
      }
      viewDirty |= ImGui::Combo("Handedness", &handedness, "Right-handed\0Left-handed\0");
      // Recompute rightHanded immediately after combo so the LookAt below uses the new value
      rightHanded = (handedness == 0);
      if (isPerspective)
      {
         viewDirty |= ImGui::Checkbox("Infinite far plane", &infiniteFarPlane);
      }
      ImGui::SliderInt("Gizmo count", &gizmoCount, 1, 4);

      if (gizmoCount > 1 && ImGui::CollapsingHeader("Gizmos enable"))
      {
         for (int matId = 0; matId < gizmoCount; matId++)
         {
            char label[32];
            snprintf(label, sizeof(label), "Gizmo %d", matId);
            ImGui::Checkbox(label, &gizmoEnabled[matId]);
         }
      }

      ImGui::Checkbox("Second view", &useSecondView);

      if (viewDirty || firstFrame)
      {
         float eye[] = { cosf(camYAngle) * cosf(camXAngle) * camDistance, sinf(camXAngle) * camDistance, sinf(camYAngle) * cosf(camXAngle) * camDistance };
         float at[] = { 0.f, 0.f, 0.f };
         float up[] = { 0.f, 1.f, 0.f };
         LookAt(eye, at, up, cameraView, rightHanded);
         firstFrame = false;
      }
      // Also refresh next frame so projection catches up when handedness changed
      static int prevHandedness = handedness;
      if (prevHandedness != handedness) { firstFrame = true; }
      prevHandedness = handedness;

      ImGui::Text("X: %f Y: %f", io.MousePos.x, io.MousePos.y);
      if (ImGuizmo::IsUsing())
      {
         ImGui::Text("Using gizmo");
      }
      else
      {
         ImGui::Text(ImGuizmo::IsOver()?"Over gizmo":"");
         ImGui::SameLine();
         ImGui::Text(ImGuizmo::IsOver(ImGuizmo::TRANSLATE) ? "Over translate gizmo" : "");
         ImGui::SameLine();
         ImGui::Text(ImGuizmo::IsOver(ImGuizmo::ROTATE) ? "Over rotate gizmo" : "");
         ImGui::SameLine();
         ImGui::Text(ImGuizmo::IsOver(ImGuizmo::SCALE) ? "Over scale gizmo" : "");
      }
      ImGui::Separator();
      
      TransformStart(cameraView, cameraProjection, objectMatrix[lastUsing], rightHanded);
      for (int matId = 0; matId < gizmoCount; matId++)
      {
          ImGuizmo::PushID(matId);

          ImGuizmo::Enable(gizmoEnabled[matId]);
          EditTransform(cameraView, cameraProjection, objectMatrix[matId]);
          if (ImGuizmo::IsUsing())
          {
              lastUsing = matId;
          }
          ImGuizmo::PopID();
      }
      TransformEnd();

      ImGui::End();

      if (useSecondView)
      {
         SecondView(isPerspective, fov, viewWidth, rightHanded, infiniteFarPlane);
      }

      ImGui::SetNextWindowPos(ImVec2(10, 500), ImGuiCond_Appearing);

      ImGui::SetNextWindowSize(ImVec2(940, 480), ImGuiCond_Appearing);
      ImGui::Begin("Other controls");
      if (ImGui::CollapsingHeader("Zoom Slider"))
      {
         static float uMin = 0.4f, uMax = 0.6f;
         static float vMin = 0.4f, vMax = 0.6f;
         ImGui::Image((ImTextureID)(uint64_t)procTexture, ImVec2(900,300), ImVec2(uMin, vMin), ImVec2(uMax, vMax));
         {
            ImGui::SameLine();
            ImGui::PushID(18);
            ImZoomSlider::ImZoomSlider(0.f, 1.f, vMin, vMax, 0.01f, ImZoomSlider::ImGuiZoomSliderFlags_Vertical);
            ImGui::PopID();
         }
      
         {
            ImGui::PushID(19);
            ImZoomSlider::ImZoomSlider(0.f, 1.f, uMin, uMax);
            ImGui::PopID();
         }
      }
      if (ImGui::CollapsingHeader("Sequencer"))
      {
         // let's create the sequencer
         static int selectedEntry = -1;
         static int firstFrame = 0;
         static bool expanded = true;
         static int currentFrame = 100;

         ImGui::PushItemWidth(130);
         ImGui::InputInt("Frame Min", &mySequence.mFrameMin);
         ImGui::SameLine();
         ImGui::InputInt("Frame ", &currentFrame);
         ImGui::SameLine();
         ImGui::InputInt("Frame Max", &mySequence.mFrameMax);
         ImGui::PopItemWidth();
         Sequencer(&mySequence, &currentFrame, &expanded, &selectedEntry, &firstFrame, ImSequencer::SEQUENCER_EDIT_STARTEND | ImSequencer::SEQUENCER_ADD | ImSequencer::SEQUENCER_DEL | ImSequencer::SEQUENCER_COPYPASTE | ImSequencer::SEQUENCER_CHANGE_FRAME);
         // add a UI to edit that particular item
         if (selectedEntry != -1)
         {
           const MySequence::MySequenceItem &item = mySequence.myItems[selectedEntry];
           ImGui::Text("I am a %s, please edit me", SequencerItemTypeNames[item.mType]);
           // switch (type) ....
         }
      }
      if (ImGui::CollapsingHeader("Vector Editor"))
      {
         ShowVectorEditorDemo();
      }

      // Graph Editor
      static GraphEditor::Options options;
      static GraphEditorDelegate delegate;
      static GraphEditor::ViewState viewState;
      static GraphEditor::FitOnScreen fit = GraphEditor::Fit_None;
      static bool showGraphEditor = true;

      if (ImGui::CollapsingHeader("Graph Editor"))
      {
         ImGui::Checkbox("Show GraphEditor", &showGraphEditor);
         GraphEditor::EditOptions(options);
      }

      // Light Rig
      if (ImGui::CollapsingHeader("Light Rig"))
      {
         static ImLightRig::Light lights[128] = {
            { 1.f, 0.3f, 0.1f,  1.f,  0.5f, 0.5f},
            { 0.3f, 1.f, 0.1f,  1.f,  -0.5f, 0.5f},
            { 0.1f, 0.3f, 1.f,  1.f,  -0.5f, -0.5f},
         };
         static int lightCount = 3;
         static int selectedLight = -1;
         selectedLight = ImLightRig::Edit(lights, lightCount, selectedLight, ImVec2(200,200));
         if (selectedLight >= 0 && selectedLight < lightCount)
         {
            auto& light = lights[selectedLight];
            ImGui::ColorEdit3("RGB", &light.r);
            ImGui::SliderFloat("Intensity", &light.intensity, 0.f, 10.f);
         }
      }

      ImGui::End();

      if (showGraphEditor)
      {
         ImGui::Begin("Graph Editor", NULL, 0);
         if (ImGui::Button("Fit all nodes"))
         {
            fit = GraphEditor::Fit_AllNodes;
         }
         ImGui::SameLine();
         if (ImGui::Button("Fit selected nodes"))
         {
            fit = GraphEditor::Fit_SelectedNodes;
         }
         GraphEditor::Show(delegate, options, viewState, true, &fit);

         ImGui::End();
      }

      // render everything
      glClearColor(0.45f, 0.4f, 0.4f, 1.f);
      glClear(GL_COLOR_BUFFER_BIT);
      imApp.EndFrame();
   }

   imApp.Finish();

   return 0;
}
